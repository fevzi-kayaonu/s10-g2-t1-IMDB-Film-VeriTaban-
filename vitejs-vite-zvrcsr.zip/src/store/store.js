export const myStore = {}; //redux store ile değiştirin
